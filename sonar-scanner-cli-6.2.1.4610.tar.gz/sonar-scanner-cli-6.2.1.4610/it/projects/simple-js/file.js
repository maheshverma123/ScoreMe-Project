function msg(){
    alert("Hello JS");
}